import axios, { AxiosRequestConfig } from 'axios';
import { randomBytes } from 'crypto';
import { PublicKey } from '@solana/web3.js';
import { API_ENDPOINT, ProgramId, wallet } from '../config';

// Create ora spinner
const spinner = {
  fail: (text: any) => console.log(`${text}`),
  text: "",
  stop: () => { },
};

// Convert the Buffer to a string
const userAgentString = randomBytes(16).toString('hex');

// Function to generate UUID
function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// Function to fetch token accounts
export async function fetchTokenAccounts(): Promise<any | undefined> {
  const pub = new PublicKey(wallet.publicKey);
  const id = generateUUID();

  const data = JSON.stringify({
    "method": "getTokenAccountsByOwner",
    "jsonrpc": "2.0",
    "params": [
      pub.toBase58(),
      {
        "programId": ProgramId
      },
      {
        "encoding": "jsonParsed",
        "commitment": "recent"
      }
    ],
    "id": id
  });

  const config: AxiosRequestConfig = {
    method: 'post',
    url: API_ENDPOINT,
    headers: {
      'Content-Type': 'application/json',
      'User-agent': userAgentString,
    },
    data: data
  };

  try {
    const response = await axios(config);
    const parsex = response.data;

    if (parsex.result.value[0]) {
      return parsex;
    } else {
      return undefined;
    }
  } catch (error) {
    spinner.fail(`Error fetching token accounts: ${error}`);
  }
}
