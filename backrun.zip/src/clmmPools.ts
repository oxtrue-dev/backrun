import { ApiClmmPoolsItem, Clmm } from '@raydium-io/raydium-sdk';
import { RAYDIUM_MAINNET_API, ENDPOINT, connection } from '../config';

// Define color variables
const Reset = '\x1b[0m';
const FgRed = '\x1b[31m';

// Create ora spinner
const spinner = {
    fail: (text: any) => console.log(`${text}`),
    text: "",
    stop: () => { },
};

async function ClmmInfoWithTimeout() {
    const timeout = 10000; // 10 seconds
    const startTime = Date.now();

    while (true) {
        try {
            // Check if the elapsed time exceeds the timeout
            if (Date.now() - startTime > timeout) {
                spinner.fail('Timeout exceeded (10 seconds)');
                return { clmmPools: [], clmmList: [] }; // or throw an error if needed
            }

            // Fetch CLMM pools from the API
            const clmmPoolsResponse = await fetch(ENDPOINT + RAYDIUM_MAINNET_API.clmmPools);
            const clmmPoolsData = await clmmPoolsResponse.json();
            const clmmPools: ApiClmmPoolsItem[] = clmmPoolsData.data;

            // Fetch CLMM pool information using the Raydium SDK
            const clmmList = Object.values(
                await Clmm.fetchMultiplePoolInfos({
                    connection,
                    poolKeys: clmmPools,
                    chainTime: new Date().getTime() / 1000,
                })
            ).map((poolInfo) => poolInfo.state);
            return { clmmPools, clmmList };
        } catch (error) {
            // Handle errors, log or rethrow as needed
            spinner.fail(`${FgRed}[Error]${Reset} ${(error as Error).message}${Reset}`);

            // Fetch CLMM pools from the API
            const clmmPoolsResponse = await fetch(ENDPOINT + RAYDIUM_MAINNET_API.clmmPools);
            const clmmPoolsData = await clmmPoolsResponse.json();
            const clmmPools: ApiClmmPoolsItem[] = clmmPoolsData.data;

            // Fetch CLMM pool information using the Raydium SDK
            const clmmList = Object.values(
                await Clmm.fetchMultiplePoolInfos({
                    connection,
                    poolKeys: clmmPools,
                    chainTime: new Date().getTime() / 1000,
                })
            ).map((poolInfo) => poolInfo.state);
            return { clmmPools, clmmList };
        }
    }
}

class TimeoutError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'TimeoutError';
    }
}

export default ClmmInfoWithTimeout;
