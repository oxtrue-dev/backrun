import { ApiPoolInfo } from '@raydium-io/raydium-sdk';
import { RAYDIUM_MAINNET_API, ENDPOINT } from '../config';

// Define color variables
const Reset = '\x1b[0m';
const FgRed = '\x1b[31m';

// Create ora spinner
const spinner = {
    fail: (text: any) => console.log(`${text}`),
    text: "",
    stop: () => { },
};

function sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function PoolInfoWithTimeout(): Promise<ApiPoolInfo> {
    const timeout = 10000; // 10 seconds

    try {
        const timeoutPromise = sleep(timeout);
        const apiPoolInfoPromise = fetch(ENDPOINT + RAYDIUM_MAINNET_API.uiPoolInfo).then((response) => response.json());

        const result = await Promise.race([timeoutPromise, apiPoolInfoPromise]);

        // If the result is from the timeoutPromise, throw an error
        if (result === timeoutPromise) {
            throw new TimeoutError('Timeout exceeded (10 seconds)');
        }

        const sPool: ApiPoolInfo = result;
        return sPool;
    } catch (error) {
        // Handle errors, log or rethrow as needed
        spinner.fail(`${FgRed}[Error]${Reset} ${(error as Error).message}${Reset}`);
        const timeoutPromise = sleep(timeout);
        const apiPoolInfoPromise = fetch(ENDPOINT + RAYDIUM_MAINNET_API.uiPoolInfo).then((response) => response.json());

        const result = await Promise.race([timeoutPromise, apiPoolInfoPromise]);
        const sPool: ApiPoolInfo = result;
        return sPool;
    }
}

class TimeoutError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'TimeoutError';
    }
}

export default PoolInfoWithTimeout;
