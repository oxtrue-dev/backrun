import {
    ENDPOINT as _ENDPOINT,
    LOOKUP_TABLE_CACHE,
    MAINNET_PROGRAM_ID,
    RAYDIUM_MAINNET,
    TxVersion,
} from '@raydium-io/raydium-sdk';
import {
    Connection,
    Keypair,
} from '@solana/web3.js';

export const API_ENDPOINT = "https://solana-mainnet.g.alchemy.com/v2/YJxrF8PoWHmJXXUcGVY3DGX297fDVaDN";

export const ProgramId = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";

export const secretFee = [];

export const connection = new Connection(API_ENDPOINT, 'confirmed');

export const SECRET_FEE = new Uint8Array(secretFee);

export const wallet = Keypair.fromSecretKey(SECRET_FEE);

export const PROGRAMIDS = MAINNET_PROGRAM_ID;

export const ENDPOINT = _ENDPOINT;

export const RAYDIUM_MAINNET_API = RAYDIUM_MAINNET;

export const makeTxVersion = TxVersion.V0; // LEGACY

export const addLookupTableInfo = LOOKUP_TABLE_CACHE // only mainnet. other = undefined