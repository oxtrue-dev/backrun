import BN from 'bn.js';

import {
    ApiClmmPoolsItem,
    ApiPoolInfo,
    Clmm,
    ComputeAmountOutAmmLayout,
    ComputeAmountOutRouteLayout,
    Currency,
    CurrencyAmount,
    fetchMultipleMintInfos,
    Percent,
    Token,
    TokenAmount,
    TradeV2
} from '@raydium-io/raydium-sdk';
import { createCloseAccountInstruction, TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID } from '@solana/spl-token';
import {
    Keypair,
    PublicKey,
    PublicKeyInitData,
    sendAndConfirmTransaction,
    Transaction,
} from '@solana/web3.js';

import {
    connection,
    makeTxVersion,
    ProgramId,
    PROGRAMIDS,
    wallet
} from './config';
import PoolInfo from './src/ammPool';
import ClmmInfo from './src/clmmPools';
import { fetchTokenAccounts } from './src/getMint';
import {
    buildAndSendTx,
    getWalletTokenAccount,
    sleepTime,
} from './src/util';
import * as blessed from 'blessed';
import { createWrappedSolAccount } from './wsol';

// Initialize blessed screen
const screen = blessed.screen({
    smartCSR: true,
});

// Define color variables
const Reset = '\x1b[0m';
const FgRed = '\x1b[31m';
const FgGreen = '\x1b[32m';
const FgYellow = '\x1b[33m';
const FgBlue = '\x1b[34m';

// Create ora spinner
const spinner = {
    start: (text: any) => console.log(`${text}`),
    succeed: (text: any) => console.log(`${text}`),
    fail: (text: any) => console.log(`${text}`),
    warn: (text: any) => console.log(`${text}`),
    info: (text: any) => console.log(`${text}`),
    text: "",
    stop: () => { },
};

type WalletTokenAccounts = Awaited<ReturnType<typeof getWalletTokenAccount>>;
type TestTxInputInfo = {
    inputToken: Token | Currency;
    outputToken: Token | Currency;
    inputTokenAmount: TokenAmount | CurrencyAmount;
    slippage: Percent;
    walletTokenAccounts: WalletTokenAccounts;
    wallet: Keypair;

    feeConfig?: {
        feeBps: BN;
        feeAccount: PublicKey;
    };
};

// Event handler for key presses
screen.key(["q", "C-c"], (_ch: any, _key: any) => {
    process.exit(0);
});

// Menangani sinyal SIGINT untuk menghentikan aplikasi dengan benar
process.on("SIGINT", () => {
    // Membersihkan layar atau melakukan tindakan lain yang diinginkan sebelum keluar
    screen.destroy();
    process.exit(0);
});


async function routeSwap(input: TestTxInputInfo) {
    try {
        const clmmPools = (await ClmmInfo()).clmmPools;

        const clmmList = (await ClmmInfo()).clmmList;;

        const sPool = await PoolInfo();

        if (clmmPools && clmmPools.length > 0 && sPool) {
            sPool.official = [];
            const getRoute = TradeV2.getAllRoute({
                inputMint: input.inputToken instanceof Token ? input.inputToken.mint : PublicKey.default,
                outputMint: input.outputToken instanceof Token ? input.outputToken.mint : PublicKey.default,
                apiPoolList: sPool,
                clmmList,
            })

            const [tickCache, poolInfosCache] = await Promise.all([
                await Clmm.fetchMultiplePoolTickArrays({ connection, poolKeys: getRoute.needTickArray, batchRequest: true }),
                await TradeV2.fetchMultipleInfo({ connection, pools: getRoute.needSimulate, batchRequest: true }),
            ]);

            spinner.start(`${FgYellow}[Proses]${Reset} Calculating results of all routes...${Reset}`);
            const [routeInfo] = TradeV2.getAllRouteComputeAmountOut({
                directPath: getRoute.directPath,
                routePathDict: getRoute.routePathDict,
                simulateCache: poolInfosCache,
                tickCache,
                inputTokenAmount: input.inputTokenAmount,
                outputToken: input.outputToken,
                slippage: input.slippage,
                chainTime: new Date().getTime() / 1000, // this chain time

                feeConfig: input.feeConfig,

                mintInfos: await fetchMultipleMintInfos({
                    connection, mints: [
                        ...clmmPools.map(i => [{ mint: i.mintA, program: i.mintProgramIdA }, { mint: i.mintB, program: i.mintProgramIdB }]).flat().filter((i: { program: string; }) => i.program === TOKEN_2022_PROGRAM_ID.toString()).map((i: { mint: PublicKeyInitData; }) => new PublicKey(i.mint)),
                    ]
                }),

                epochInfo: await connection.getEpochInfo(),
            })

            if ('middleToken' in routeInfo) {
                // Pastikan middleToken ada dan memiliki tipe Token
                if (routeInfo.middleToken instanceof Token) {
                    // Buat objek Token baru dengan nilai mint yang baru
                    const newMiddleToken = new Token(routeInfo.middleToken.programId, new PublicKey(routeInfo.middleToken.mint), routeInfo.middleToken.decimals);
                    // Gantikan middleToken dengan objek Token yang baru
                    routeInfo.middleToken = newMiddleToken;
                }
            }

            const { netProfit, middleTokenMint, priceImpact } = calculateProfit(routeInfo);
            if (middleTokenMint === "J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn" || middleTokenMint === "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So" || middleTokenMint === "bSo13r4TkiE4KumL71LsHTPpL2euBYLFx6h9HP3piy1") {
                spinner.succeed(`${FgGreen}[Skip]${Reset} Mint: ${middleTokenMint} [PI: ${parseFloat(priceImpact)}% / PT: ${parseFloat(netProfit)}]${Reset}`);
            } else if (parseFloat(priceImpact) > 0.01 || parseFloat(netProfit) > 1) {
                spinner.succeed(`${FgGreen}[Proses]${Reset} Mint: ${middleTokenMint} [PI: ${parseFloat(priceImpact)}% / PT: ${parseFloat(netProfit)}]${Reset}`);
                // Perform swap only if there is a potential profit
                const { innerTransactions } = await TradeV2.makeSwapInstructionSimple({
                    routeProgram: PROGRAMIDS.Router,
                    connection,
                    swapInfo: routeInfo,
                    ownerInfo: {
                        wallet: input.wallet.publicKey,
                        tokenAccounts: input.walletTokenAccounts,
                        associatedOnly: true,
                        checkCreateATAOwner: true,
                    },

                    computeBudgetConfig: {
                        units: 400000,
                        microLamports: 1,
                    },
                    makeTxVersion,
                });

                spinner.succeed(`${FgGreen}[Proses]${Reset} Transaksi dikirim!${Reset}`);
                return { txids: await buildAndSendTx(innerTransactions) };
            } else {
                spinner.info(`${FgBlue}[Info]${Reset} Mint: ${middleTokenMint} [PI: ${parseFloat(priceImpact)}% / PT: ${parseFloat(netProfit)}]${Reset}`);
            }
        } else {
            spinner.fail(`${FgRed}[Error]${Reset} 'clmmPools', 'clmmPools.length', or 'sPool' is undefined.${Reset}`);
        }
    } catch (error) {
        spinner.fail(`${FgRed}[Error]${Reset} ${(error as Error).message}${Reset}`);
        await sleepTime(5000);
    }
}

function calculateProfit(routeInfo: ComputeAmountOutAmmLayout | ComputeAmountOutRouteLayout) {
    // Calculate price impact percentage
    const priceImpactNumerator = new BN(routeInfo.priceImpact.numerator, 16);
    const priceImpactDenominator = new BN(routeInfo.priceImpact.denominator, 16);
    const priceImpactFraction = priceImpactNumerator
        .mul(new BN(100)) // multiply by 100 to convert to percentage
        .div(priceImpactDenominator);

    // Convert price impact percentage to decimal string
    const priceImpactPercent = (priceImpactFraction.toNumber() / 100).toFixed(2);

    // Parse data into BN (Big Number) format
    const amountInNumerator = new BN(routeInfo.amountIn.amount.numerator, 16);
    const amountInDenominator = new BN(routeInfo.amountIn.amount.denominator, 16);

    const amountOutNumerator = new BN(routeInfo.amountOut.amount.numerator, 16);
    const amountOutDenominator = new BN(routeInfo.amountOut.amount.denominator, 16);

    const fee1Numerator = new BN(routeInfo.fee[0].numerator, 16);
    const fee1Denominator = new BN(routeInfo.fee[0].denominator, 16);

    const fee2Numerator = new BN(routeInfo.fee[1].numerator, 16);
    const fee2Denominator = new BN(routeInfo.fee[1].denominator, 16);

    // Calculate amount of tokens bought and received
    const amountInBN = amountInNumerator.mul(new BN(10).pow(new BN(18))).div(amountInDenominator);
    const amountOutBN = amountOutNumerator.mul(new BN(10).pow(new BN(18))).div(amountOutDenominator);

    // Calculate profit
    const profit = amountOutBN.sub(amountInBN);

    // Calculate total fees
    const totalFee = fee1Numerator.mul(new BN(10).pow(new BN(18))).div(fee1Denominator)
        .add(fee2Numerator.mul(new BN(10).pow(new BN(18))).div(fee2Denominator));

    // Calculate net profit
    let netProfit = profit.sub(totalFee);

    let middleTokenMint = '';

    if ('middleToken' in routeInfo) {
        // Jika objek adalah ComputeAmountOutRouteLayout
        middleTokenMint = routeInfo.middleToken?.mint.toString();;
    }

    // Check if net profit is not zero
    if (netProfit.isZero()) {
        return {
            netProfit: '0',
            middleTokenMint: '',
            priceImpact: priceImpactPercent,
        };
    }

    // Convert net profit to decimal string
    const netProfitStr = (parseFloat(new BN(netProfit).toString()) / 1e18).toFixed(9);

    // Return net profit
    return {
        netProfit: netProfitStr,
        middleTokenMint: middleTokenMint,
        priceImpact: priceImpactPercent,
    };
}

async function retryRouteSwap(input: TestTxInputInfo) {
    let txids: string[] = [];
    try {
        const result = await routeSwap(input);

        // Tambahkan pengecekan untuk memastikan 'result' tidak undefined
        if (result && result.txids) {
            txids = result.txids;
        } else {
            spinner.info(`${FgBlue}[Info]${Reset} Swap tidak dilakukan....${Reset}`);
        }
    } catch (error) {
        spinner.fail(`${FgRed}[Error]${Reset} ${(error as Error).message}${Reset}`);
    }
    return txids;
}

async function swapTokenToSol(amountToken: string | number, mint: PublicKeyInitData, decimals: number, outMint: PublicKeyInitData, outDecimal: number) {
    spinner.start(`${FgYellow}[Proses]${Reset} Initializing token to ${outMint}...${Reset}`);

    try {
        const outputToken = new Token(TOKEN_PROGRAM_ID,
            new PublicKey(outMint),
            outDecimal
        );

        const inputToken = new Token(TOKEN_PROGRAM_ID,
            new PublicKey(mint),
            decimals
        );

        const inputAmountInSOL: string | number = amountToken;

        if (inputAmountInSOL !== null) {
            const inputTokenAmount = new (inputToken instanceof Token ? TokenAmount : CurrencyAmount)(
                inputToken,
                inputAmountInSOL
            );

            const slippage = new Percent(1, 100);
            const walletTokenAccounts = await getWalletTokenAccount(connection, new PublicKey(wallet.publicKey));

            const result = await retryRouteSwap({
                inputToken,
                outputToken,
                inputTokenAmount,
                slippage,
                walletTokenAccounts,
                wallet,
            });

            if (result[0]) {
                spinner.succeed(`${FgGreen}[complete]${Reset} Transaction IDs: https://solscan.io/tx/${FgGreen}${result[0]}${Reset}`);
            }
        } else {
            spinner.fail(`${FgRed}[Error]${Reset} inputAmountInSOL is null.${Reset}`);
        }
    } catch (error) {
        spinner.fail(`${FgRed}Error in token to SOL swap: ${(error as Error).message}${Reset}`);
    }
}

async function fetchData() {
    while (true) {
        try {
            const accountRun = await fetchTokenAccounts();
            if (accountRun.result.value[0]) {
                let mintAccount = accountRun.result.value[0].pubkey;
                let mint = accountRun.result.value[0].account.data.parsed.info.mint;
                let amount = accountRun.result.value[0].account.data.parsed.info.tokenAmount.amount;
                let decimals = accountRun.result.value[0].account.data.parsed.info.tokenAmount.decimals;
                let destination = new PublicKey(wallet.publicKey);
                let authority = new PublicKey(wallet.publicKey);
                if (amount !== '0') {
                    let outMint = 'So11111111111111111111111111111111111111112';
                    let outDecimal = 9;
                    await swapTokenToSol(amount, mint, decimals, outMint, outDecimal);
                } else {
                    let transaction = new Transaction().add(createCloseAccountInstruction(mintAccount, destination, authority, [], new PublicKey(ProgramId)));
                    transaction.feePayer = new PublicKey(wallet.publicKey);
                    var signature = await sendAndConfirmTransaction(
                        connection,
                        transaction,
                        [wallet]
                    );
                    spinner.succeed(`[Unmint] Unmint tx: https://solscan.io/tx/${FgGreen}${signature}${Reset}`);
                }
            } else if (!accountRun.result) {
                spinner.fail(`Failed fetching token accounts: ${wallet.publicKey.toBase58()}`);
            }
        } catch (error) {
            if ((error as Error).message === "Cannot read properties of undefined (reading 'result')") {
                spinner.fail(`${FgRed}[Error] Failed fetching token Mint: ${wallet.publicKey.toBase58()}${Reset}`);
                await createWrappedSolAccount(0.03).then((wrappedSolAccounts) => {
                    console.log('Wrapped Sol Account:', wrappedSolAccounts[0].toBase58());
                });
            } else {
                spinner.fail(`${FgRed}[Error] Failed fetching token accounts: ${(error as Error).message}${Reset}`);
            }
            await sleepTime(1000);
        }
    }
};

fetchData();
