import {
    ENDPOINT as _ENDPOINT,
} from '@raydium-io/raydium-sdk';
import { createWrappedNativeAccount } from "@solana/spl-token";
import {
    LAMPORTS_PER_SOL,
    PublicKey,
} from '@solana/web3.js';
import {wallet, connection} from './config'

export async function createWrappedSolAccount(amount: number): Promise<PublicKey[]> {
    const wrappedSOLMintAcc = await createWrappedNativeAccount(connection, wallet, wallet.publicKey, amount * LAMPORTS_PER_SOL);
    console.log(wrappedSOLMintAcc);
    return [wrappedSOLMintAcc]; // Wrap the result in an array
}